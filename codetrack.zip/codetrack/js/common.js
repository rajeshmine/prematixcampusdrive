$(document).ready(function () {


    document.onkeydown = function (e) {
        if (e.ctrlKey &&
            (e.keyCode === 67 ||
                e.keyCode === 86 ||
                e.keyCode === 85 ||
                e.keyCode === 117)) {

            return false;
        } else {
            return true;
        }
    };


    
// document.onkeydown = function (e) {
//     if (event.keyCode == 123) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.shiftKey && e.keyCode == 'R'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.keyCode == 'R'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.keyCode == 'C'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.keyCode == 'V'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.altKey && e.ctrlKey && e.keyCode == 'V'.charCodeAt(0)) {
//         return false;
//     }
//     if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
//         return false;
//     }
// }



    document.querySelectorAll('a[href^=""]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
    $("#sidebar").mCustomScrollbar({
        theme: "minimal"
    });
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar, #content').toggleClass('active');
        $('.collapse.in').toggleClass('in');
        $('a[aria-expanded=true]').attr('aria-expanded', 'false');
    });
});

$(document).ready(function () {
    quotes();
    history.pushState(null, null, location.href);
      window.onpopstate = function () {
          history.go(1);
      };
  });

  
let quotesArr = [
    "A job interview is not a test of your knowledge, but your ability to use it at the right time",
    "With strong strength and determination,you can go places in life,Never lose your confidence and     stay focused to achieve what you want,All the best for your interview.",
    `hink of all the skills you have,
    Think of all the intent you have,
    Then take a deep breath  
    And give your best shot at your interview,
    
    All the very best`,
    `Confidence 
    doesn't come when
     you have all the answers.
    But it comes when your ready to face
     all the questions. 
    
    All the best`, `Never be nervous when
    given the opportunity to 
   market your skills and
    talent.
   
   Good luck for you`, `If you give your best shot,
   You will really excel through,
   If you try hard, 
  Everything will change for new, 
  So all the very best for your job `, `Think of your job interview as a battle
  in which your work experience is your strategy, 
 skills are your ammunition, 
 nervousness is your enemy and 
 confidence is your ally.
 
 Good Luck.`, `Forget about acceptance. 
 Forget about rejection. 
 Focus on what’s in-between – your interview. 
 
 Do well.`, `Interviews may be tough and leave you feeling 
 nervous.But your talent and focus will win
 them over. Good luck for the day and may you observe the results`, `Your hard work and determination will
 pave way for glorious results. Wishing 
 you great success in your interview`
];

function quotes() {
    $('#quotesDiv').text(quotesArr[Math.floor(Math.random() * 10)]);
}