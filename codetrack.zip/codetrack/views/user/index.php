<?php 
include_once('../../config/connection.php');
$testtype = $_SESSION['TestType'];
?>

<!-- <!DOCTYPE html>
<html lang="en">

<head>
    <title>Code Track</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <link rel="stylesheet" href="../../css/user.css">
    <script src="../../js/common.js"></script>

</head>

<body>
    <div class="topdiv">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Code Track</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">

                    <ul class="nav navbar-nav navbar-right">

                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="pad100">
                <h3 class="white">Before Start Test</h3>
                <p class="white">Follow the instructions.</p>
                <p class="white">Mutiple Rounds are there.All Rounds have an Group of Questions.</p>
                <p class="white">Each Round have an Eligibility Creteria.</p>
                <p class="white">Don't Refresh the Page.</p>
                <div class="text-right">
                    <?php 
                    if ($testtype == 'Coding') {

                        echo '<button onclick="location.href=\'codingtest/codingtest.php\'" class="starttestbtn">START TEST</button>';

                    } else {
                        echo '<button onclick="location.href=\'test/test.php\'" class="starttestbtn">START TEST</button>';
                    }
                    ?>
                   
                </div>
            </div>

        </div>
    </div>
    <div class="container-fluid">
        <div class="flexdiv">
            <div>
                <h4>Apptitude</h4>
                <p>First Round is an Apptitude Round.</p>
                <p>Questions are in MCQ Format.</p>
            </div>
            <div>
                <h4>Technical</h4>
                <p>Second Round is an Technical Round.</p>
                <p>Questions are in MCQ Format.</p>
            </div>
            <div>
                <h4>Coding</h4>
                <p>Final Round is an Codind Round.</p>
                <p>Questions are in Sentence Format.</p>
            </div>
        </div>
    </div>
</body>

</html> -->


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Code Track</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <link rel="stylesheet" href="../../css/user.css">
    <script src="../../js/common.js"></script>

</head>

<body>
    <div class="topdiv">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Prematix OnCampus</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">

                    <ul class="nav navbar-nav navbar-right">

                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="pad100 bg-set">
                <h3 class="white">Before Start Test</h3>
                <p class="white">Follow the instructions.</p>
                <ul>
                    <li class="white">All the Questions have Multiple Choice.</li>
                    <li class="white">There is No negative Marks</li>
                    <li class="white">Try to Understand the Concept and Give answer.</li>
                    <li class="white">Each Question Carries 1 mark.</li>
                </ul>
               
            </div>

            <div class="text-center">
                <?php 
                if ($testtype == 'Coding') {

                    echo '<button onclick="location.href=\'codingtest/codingtest.php\'" class="starttestbtn">START TEST</button>';

                } else {
                    echo '<button onclick="location.href=\'test/test.php\'" class="starttestbtn">START TEST</button>';
                }
                ?>

            </div>

            <br>
        </div>
    </div>
    <div class="container-fluid">
        <br>
        <div class="row">
            <div class="col-md-2">
                
            </div>
            <div class="col-md-8">
                <div class="row" style="box-shadow: 0 0.35rem 0.25rem 0 rgba(0, 0, 0, 0.1);background:#fff;">
                    <div class="col-md-4">
                        
                        <div>
                            <img style="width: 100%;" src="../../image/logo_temp.jpg">
                        </div>
                    </div>
                    <div class="col-md-8">
                    
                        <div id="quotesDiv">
                        A job interview is not a test of your knowledge, but your ability to use it at the right time
                        </div>
                    </div>
                </div>
               
            </div>

            <div class="col-md-2">
                
            </div>

        </div>
    </div>
    <div class="container-fluid">
        <div class="flexdiv">
            <div>
                <h4><img style="width:50px;" src="../../image/aptitude5_1.png"> Aptitude</h4>
                
                <p>First Round is an Aptitude Round.</p>
                <p>Questions are in MCQ Format.</p>
            </div>
            <div>
                <h4><img style="width:50px;" src="../../image/technical_1.png"> Technical</h4>
                
                <p>Second Round is an Technical Round.</p>
                <p>Questions are in MCQ Format.</p>
            </div>
            <div>
                 <h4><img style="width:50px;" src="../../image/09_05_2017_why_coding_infographic_blog_pvS_1.ico"> Programming</h4>
                
                <p>Level 2 Round is an Programming Round.</p>
                <p>Questions are in Sentence Format.</p>
            </div>
        </div>
    </div>
</body>

</html>