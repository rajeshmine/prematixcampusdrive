print('Hello, world!') 
