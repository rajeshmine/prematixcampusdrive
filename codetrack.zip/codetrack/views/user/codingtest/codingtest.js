let formdata = new FormData();
let code, input, lang, inputRadio = 'false', javacode, pythoncode, htmlcode, pbmno;

javacode = `
<textarea rows="4" cols="50" name="code" id="code">

class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!"); 
    }
}
</textarea>
`;
pythoncode = `
<textarea rows="4" cols="50" name="code" id="code">
print('Hello, world!') 
</textarea>
`;

htmlcode = `
<textarea rows="4" cols="50" name="code" id="code">
    <html>
        <head>
        </head>
        <body>
            <h2>Welcome</h2>
        </body>
    </html>
</textarea>
`;
$(document).ready(function () {


    document.onkeydown = function (e) {
        if (e.ctrlKey &&
            (e.keyCode === 67 ||
                e.keyCode === 86 ||
                e.keyCode === 85 ||
                e.keyCode === 117)) {

            return false;
        } else {
            return true;
        }
    };

    $("body").on("contextmenu", function (e) {
        return false;
    });


    $('#inputdiv,#outputscreen,.settingsdiv,.problemholediv,.compilerholediv').hide();
    $('#inputRadio').change(function () {
        if ($(this).prop("checked")) {
            inputRadio = 'true';
            $('#inputdiv').show();
        } else {
            inputRadio = 'false';
            $('#inputdiv').hide();
        }
    });
    codemirrorkeyup();
    $('#languageselect').change(function () {
        if ($(this).val() === 'html') {
            $('#previewTarget').css("background", "#fff");
            inputoutputscreenreset();
            $('#inputRadiocolumn').hide();
            $('.codeouterdiv').empty();
            $('.codeouterdiv').append(htmlcode);
            CodeMirrorInit('text/html');
            codemirrorkeyup();
        } else if ($(this).val() === 'python') {
            $('#previewTarget').css("background", "#000");
            inputoutputscreenreset();
            $('#inputRadiocolumn').show();
            $('.codeouterdiv').empty();
            $('.codeouterdiv').append(pythoncode);
            CodeMirrorInit('text/x-python');
            codemirrorkeyup();
        } else if ($(this).val() === 'java') {
            $('#previewTarget').css("background", "#000");
            inputoutputscreenreset();
            $('#inputRadiocolumn').show();
            $('.codeouterdiv').empty();
            $('.codeouterdiv').append(javacode);
            CodeMirrorInit('text/x-java');
            codemirrorkeyup();
        }
    });


});




function codemirrorkeyup() {
    $('.CodeMirror').keyup(function () {
        updateTextArea();
    });
}
function compilecode() {
    let url = `compile.php`;
    code = $('#code').val();
    lang = $('#languageselect').val();
    input = $('#input').val();
    if (lang === 'html') {
        $('#previewTarget').css("background", "#fff");
    }
    var dataString = 'code=' + encodeURIComponent(code) + '&input=' + encodeURIComponent(input) + '&language=' + encodeURIComponent(lang);
    if (lang !== '') {
        if (lang === 'html') {
            $('#outputscreen').show();
            var targetp = $("#previewTarget")[0].contentWindow.document;
            targetp.open();
            targetp.close();
            $('body', targetp).append(code);
        } else {

            if (code !== '') {
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: dataString,

                }).done(data => {
                    if (data) {
                        $('#outputscreen').show();
                        var targetp = $("#previewTarget")[0].contentWindow.document;
                        targetp.open();
                        targetp.close();
                        $('body', targetp).append(`<b style="color:#fff;">${data}</b>`);
                    }

                }).catch(e => {
                    alert(`URL : ${url}\nStatusCode:${e.status}\nDescription:${e.statusText}`);
                });
            } else {
                alert('Input Should not Empty!!!')
            }


        }
    } else {
        alert('Select Language');
    }
}
var editableCodeMirror;
function CodeMirrorInit(language) {
    editableCodeMirror = CodeMirror.fromTextArea(document.getElementById('code'), {
        mode: language,
        lineNumbers: true,
        styleSelectedText: true,
        lineWrapping: true,
        styleActiveLine: true,
        styleActiveSelected: true,
    });

}



function updateTextArea() {
    editableCodeMirror.save();
}

$(document).ready(function () {
    $('.themebtn').each(function () {
        $(this).click(function () {
            $('.themebtn').removeClass('themeselected');
            $(this).addClass('themeselected');
            selectTheme($(this).val());
        });
    });
});
function selectTheme(theme) {
    editableCodeMirror.setOption("theme", theme);
}
function settingsdivtoggle() {
    $('.settingsdiv').toggle();
}
function inputoutputscreenreset() {
    $('#input').val('');
    $("#inputRadio").prop('checked', false);
    inputRadio = 'false';
    var targetp = $("#previewTarget")[0].contentWindow.document;
    targetp.open();
    targetp.close();
    $('body', targetp).append('');
    $('#inputdiv,#outputscreen,.settingsdiv').hide();
}



function problemget(limit) {

    $.get(`getproblem.php?limit=${limit}`, function (data, status) {
        if (status === 'success') {
            if (data) {
                let tempData = JSON.parse(data);
                if (tempData.length > 0) {
                    $('.problemdiv').empty();

                    for (let i = 0; i < tempData.length; i++) {
                        $('.problemdiv').append(`
                            <div class="problem">
                                <h4>${tempData[i].problem}</h4>
                                <p>${tempData[i].description}</p>
                                <div class="solveproblembtndiv">
                                    <button onclick="singleproblemget(${tempData[i].sno})" class="solveproblembtn">Solve Problem</button>
                                </div>                                
                            </div>
                        `);
                    }
                    
                    $('.problemholediv').show();
                } else {

                    console.log(data);
                }
            } else {
                console.log(data);
            }
        } else {
            alert('Failed to Get Data!!!')
        }
    });
}


function singleproblemget(sno) {
   
    pbmno = sno;
    inputoutputscreenreset();
    $('#inputdiv,#outputscreen,.settingsdiv,.problemholediv').hide();
    $('.compilerholediv').show();
    $.get(`getsingleproblem.php?sno=${sno}`, function (data, status) {
        if (status === 'success') {
            if (data) {
               
                let tempData = JSON.parse(data);
                if (tempData.length > 0) {
                    $('.pbmstmtdiv').empty();
                    for (let i = 0; i < tempData.length; i++) {
                        $('.pbmstmtdiv').append(
                            `
                           <h4><span style="border-bottom:2px solid;padding:6px;">Problem Statement</span></h4>
                            <div class="pad10">
                                <h3>${tempData[i].problem}</h3>
                                <p>${tempData[i].description}</p>
                            </div>  
                            
                            <div class="pad10">
                                <h5 class="headtxt">Input Format</h5>
                                <pre>${tempData[i].inputformat}</pre>
                            </div>  
                            <div class="pad10">
                                <h5 class="headtxt">Constraints</h5>
                                <pre>${tempData[i].constraints}</pre>

                            </div>  
                            <div class="pad10">
                                <h5 class="headtxt">Output Format</h5>
                                <pre>${tempData[i].outputformat}</pre>
                            </div>  
                            <div class="pad10">
                                <h5 class="headtxt">Sample TestCase</h5>
                                <p>Input</p>
                                <div class="sampleinputdiv">
                                    <pre>${tempData[i].sampleinput}</pre>
                                </div>
                            </div>  
                            <div class="pad10">                        
                                <p>Output</p>
                                <div class="sampleinputdiv">
                                <pre>${tempData[i].sampleoutput}</pre>
                                </div>
                            </div> 
                           `
                        );
                        filepathget(sno);
                    }
                   

                } else {
                   

                }
            } else {
                console.log(data);
            }
        } else {
            alert('Failed to Get Data!!!')
        }
    });
}

function filepathget(sno){
    $.get(`getfilepath.php?sno=${sno}`, function (data, status) {
        if (status.trim() === 'success') {
            if (data) {
                
                let tempData = JSON.parse(data);

                if (tempData.length > 0) {
                    readFile(tempData[0].filepath)
                }else{
                    $('.codeouterdiv').empty();
                    javacode = `
<textarea rows="4" cols="50" name="code" id="code">
class Main {
public static void main(String[] args) {
System.out.println("Hello, World!"); 
}
}
</textarea>
`;
                    $('.codeouterdiv').append(javacode.trim());
                    CodeMirrorInit('text/x-java');
                    codemirrorkeyup();
                }
            }
        }
    });
}
function readFile(file) {
    console.log(file)
    if (file) {
        let lang = file.split('.')[1];
        if (lang === 'py') {
            lang = 'python';
        }
        $('#languageselect').val(lang);

        fetch(file)
            .then(response => response.text())
            .then(text => {
                $('.codeouterdiv').empty();

                $('.codeouterdiv').append(`
<textarea rows="4" cols="50" name="code" id="code">
${text}
</textarea>
    `);
                if (lang === 'python') {
                    CodeMirrorInit('text/x-python');
                } else if (lang === 'java') {
                    CodeMirrorInit('text/x-java');
                } else if (lang === 'html') {
                    CodeMirrorInit('text/html');
                }

                codemirrorkeyup();
            });
    }else{
       
    }
}

function submitcodefun() {
    var code = $('#code').val();
    var lang = $('#languageselect').val();


    $.confirm({
        title: 'Confirm!',
        content: 'Are you want to Submit this Code!!!',
        buttons: {
            confirm: function () {
                $.ajax({
                    url: "submitcode.php",
                    type: "post",
                    data: {
                        code: code,
                        lang: lang,
                        sno: pbmno
                    },
                    success: function (result) {
                        $('.problemholediv').show();
                        $('.compilerholediv').hide();
                    }
                });
            },
            cancel: function () {

            }
        }
    });



}


function timeoutfun(){
    var code = $('#code').val();
    var lang = $('#languageselect').val();
    $.ajax({
        url: "submitcode.php",
        type: "post",
        data: {
            code: code,
            lang: lang,
            sno: pbmno
        },
        success: function (result) {
            $.confirm({
                title: 'Alert!',
                type: 'red',
                content: 'TimeOut!!!',
                autoClose: 'confirm|2000',
                buttons: {
                    confirm: function () {
                        location.href = "../finalpage/finalpage.php";
                    }
                }
            });
        
            
        }
    });
   
}



function finishtest() {
    $.confirm({
        title: 'Confirm!',
        content: 'Are you want to Finish this Test!!!',
        buttons: {
            confirm: function () {
                location.href = "../finalpage/finalpage.php";
            },
            cancel: function () {

            }
        }
    });

}

let questions, cutoff;

function gettimedetails() {
    $.get("gettime.php", function (data, status) {
        if (status.trim() === 'success') {
            if (data) {
                let tempData = JSON.parse(data);

                if (tempData.length > 0) {
                    questions = tempData[0].questions;
                    timer(tempData[0].time);
                    cutoff = tempData[0].cutoff;
                    timer(tempData[0].time);
                    problemget(questions);
                }
            }
        }
    });
}

function timer(min) {

    var insertZero = n => n < 10 ? "0" + n : "" + n,
        displayTime = n => n ? time.textContent = insertZero(~~(n / 3600) % 3600) + ":" +
            insertZero(~~(n / 60) % 60) + ":" +
            insertZero(n % 60)
            : timeoutfun(),
        countDownFrom = n => (displayTime(n), setTimeout(_ => n ? sid = countDownFrom(--n)
            : displayTime(n), 1000)), sid;
    countDownFrom(+(min * 60));

}