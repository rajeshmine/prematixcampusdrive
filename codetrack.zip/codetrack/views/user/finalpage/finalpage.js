function gotonextround(){
    location.href="../test/test.php";
}
function gotofinalround(){
    location.href="../problem/problem.php";
}
function completetest(){
    location.href="../../../index.html";
}