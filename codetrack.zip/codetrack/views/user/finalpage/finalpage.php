<?php
    include_once('../../../config/connection.php');
    $testtype = $_SESSION['TestType'];
    $username= $_SESSION['Email'];
    $name= $_SESSION['Name'];

    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Code Track</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <link rel="stylesheet" href="../../../css/user.css">
    <link rel="stylesheet" href="finalpage.css">
    <script src="finalpage.js"></script>
    <script src="../../../js/common.js"></script>

</head>

<body>
    <div class="topdiv pad10">
        <nav class="navbar">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Prematix OnCampus</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <p id="time"></p>                        
                    </ul>
                </div>
            </div>
        </nav>
        
    </div>
    <div class="container-fluid">
        <div class="row mar0 pad10">
           
            <?php
                if($testtype === 'Apptitude'){
                    $_SESSION['TestType']= 'Technical';
                    $sql = "UPDATE `login` SET `teststatus`= 'Technical' WHERE `email`='$username'";
                    $result=mysqli_query($con,$sql) or die(mysqli_error());
                        if($result){
                            echo "<div class='text-center' >
                                    <h2>Dear  $name </h2>
                                <h3>You are Successfully Completed the Apptitude Test. Technical Round Starting within 5 Seconds...</h3>
                
                                </div>
                            ";
                            echo "<script>setTimeout(function(){location.href='../test/test.php'}, 5000);</script>";
                           
                        }
                   
                   
                }else if($testtype === 'Technical'){
                    $sql = "UPDATE `login` SET `status`= 'N' WHERE `email`='$username'";
                    $result=mysqli_query($con,$sql) or die(mysqli_error());
                        if($result){
                            
                            echo "<div class='text-center' >
                                 <h2>Dear  $name </h2>
                             <h3>You are Successfully Completed the Test. Wait for the Result...</h3>
                
                             </div>
                            ";

                            echo "<script>setTimeout(function(){location.href='../../../index.html'}, 5000);</script>";
                           
                            
                        }
                }else{               
                   
                    echo "<div class='text-center' >
                            <h2>Dear  $name </h2>
                         <h3>You are Successfully Completed the Test. Wait for the Result...</h3>        
                        </div>
                    ";

                    echo "<script>setTimeout(function(){location.href='../../../index.html'}, 5000);</script>";
                }
            ?>
           
        </div>
    </div>


</body>

</html>


       