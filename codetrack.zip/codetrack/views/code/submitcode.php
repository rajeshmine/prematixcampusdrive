<?php
    date_default_timezone_set('Asia/Kolkata');
    $GLOBALS['code'] = $_POST['code'];
    $GLOBALS['lang'] = $_POST['lang'];       
    if (!file_exists('Temp')) {
        mkdir('Temp', 0777, true);
        $myfile = fopen("Temp/".date( "dmY_His").".".strtolower($GLOBALS['lang']), "w") or die("Unable to open file!");
        $txt = $GLOBALS['code'];
        fwrite($myfile, $txt);
        fclose($myfile);
    }else{
        $myfile = fopen("Temp/".date( "dmY_His").".".strtolower($GLOBALS['lang']), "w") or die("Unable to open file!");  
        $txt = $GLOBALS['code'];
        fwrite($myfile, $txt);
        fclose($myfile);
    }  
?>