<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
</head>
<body>

<?php
	include_once('../../../config/connection.php');
	$username=$_SESSION['Email'];
	
	if(isset($_POST['problemaddbtn'])){
		$problem = $_POST['problem'];
		$description = $_POST['description'];
		$inputformat = $_POST['inputformat'];
		$constraints = $_POST['constraints'];
		$outputformat = $_POST['outputformat'];
		$sampleinput = $_POST['sampleinput'];
		$sampleoutput = $_POST['sampleoutput'];
		
		$query = "INSERT INTO `problem`( `problem`, `description`, `inputformat`, `constraints`, `outputformat`, `sampleinput`, `sampleoutput`, `createdby`) VALUES ('$problem','$description','$inputformat','$constraints','$outputformat','$sampleinput','$sampleoutput','$username')";
		$result=mysqli_query($con,$query) or die(mysqli_error());
		if($result){
			echo "<script>$.confirm({
				title: 'Success',
				content: 'Problem Inserted Successfully',
				autoClose: 'ok|1000',						
				buttons: {							
					ok: function () {
						location.href='question.php';
					}
				}
			});
			</script>";
			
		}else{
			echo "<script>$.confirm({
				title: 'Failure',
				content: 'Problem Inserted Failed',
				autoClose: 'ok|1000',						
				buttons: {							
					ok: function () {
						location.href='question.php';
					}
				}
			});
			</script>";
			
		}		
	}

	
?>

</body>
</html>