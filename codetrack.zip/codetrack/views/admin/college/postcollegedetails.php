<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
</head>
<body>
<?php
	include_once('../../../config/connection.php');
	$username=$_SESSION['Email'];
	if(isset($_POST['collegeaddbtn'])){
		$collegeid = $_POST['collegeid'];
		$collegename = $_POST['collegename'];
		$interviewdate = $_POST['interviewdate'];
		$query = "SELECT * FROM `college` WHERE `collegeid`='$collegeid' OR `collegename`='$collegename'";
		$duplicatefind=mysqli_query($con,$query) or die(mysqli_error());
		if($duplicatefind){
			$rowcount=mysqli_num_rows($duplicatefind);
			if($rowcount === 0){
				$sql = "INSERT INTO `college`( `collegeid`, `collegename`, `interviewdate`,  `createdby`) VALUES ('$collegeid','$collegename','$interviewdate','$username')";
				$result=mysqli_query($con,$sql) or die(mysqli_error());
				if($result){
				
					echo "<script>$.confirm({
						title: 'Success',
						content: 'Insert College Details Successfully',	
						autoClose: 'ok|1000',					
						buttons: {							
							ok: function () {
								location.href='college.php';
							}
						}
					});
					</script>";
				}else{
					echo '<script>alert('.mysqli_error().')</script>';
				}
			}else{

				echo "<script>$.confirm({
					title: 'Failure',
					content: 'College Details Already Exists',
					autoClose: 'ok|1000',						
					buttons: {							
						ok: function () {
							location.href='college.php';
						}
					}
				});
				</script>";
				
			}
		}
		
	}
?>
</body>
</html>