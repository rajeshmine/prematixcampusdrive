<?php
	include_once('../../../config/connection.php');
	$collegeid = $_GET['collegeid'];
	$course = $_GET['course'];
	$department = $_GET['department'];
	$sql = "SELECT * FROM `login` WHERE `role`='user' AND `collegeid`='$collegeid' AND `course`='$course' AND `department`='$department' ";
	$result=mysqli_query($con,$sql) or die(mysqli_error());
	while($rows=mysqli_fetch_array($result)){
		$data[] = $rows;
	}
	if(isset($data)){
		echo json_encode($data);	
	}else{
		$oVal = (object)[];
		echo json_encode($oVal);
	}	
?>