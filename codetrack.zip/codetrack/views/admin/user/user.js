let email = [], usersno = 0;
$(document).ready(function () {
	$('.usertablediv,.usersno').hide();
	var date = new Date();
	let currentyear = date.getFullYear() + 1;
	$('.datepicker').datepicker({
		dateFormat: 'yy-mm-dd',
		changeMonth: true,
		changeYear: true,
		yearRange: "1990:" + currentyear,
	});
	$('.yearofpassing').datepicker({
		dateFormat: 'yy-mm-dd',
		changeMonth: true,
		changeYear: true,
		yearRange: "2010:" + currentyear,
	});
	departmentdetget();
});

function checkallfun() {
	
	$(".checkall").change(function () {
		email = [];
		var ischecked = $(this).is(':checked');
		if (ischecked) {
			$('.singlecheckbox').prop('checked', true);
			for (let i = 0; i < $('.singlecheckbox').length; i++) {
				let emailid = $('.singlecheckbox')[i];
				email.push(emailid.value);
			}
		} else {
			$('.singlecheckbox').prop('checked', false);
			email = [];
		}
		
	});
	
}

function singlecheckboxfun(e) {
	
	if(e.target.checked  === true){
		var removeItem = e.target.value;
		email = jQuery.grep(email, function (value) {
			return value != removeItem;
		});
		email.push(e.target.value);
	}else{
		var removeItem = e.target.value;
		email = jQuery.grep(email, function (value) {
			return value != removeItem;
		});
	}
	
}

let filtercollege, filtercourse, filterdepartment;
function filteruserresult() {
	filtercollege = $('select[name="filtercollege"]').val();
	filtercourse = $('select[name="filtercourse"]').val();
	filterdepartment = $('select[name="filterdepartment"]').val();
	if (filterdepartment && filtercourse && filtercollege) {
		userdetailsget(filtercollege, filtercourse, filterdepartment)
	}
	$('.usertablediv').show();

}

function userdetailsget(collegeid, course, department) {
	$.get(`getuserdetails.php?collegeid=${collegeid}&course=${course}&department=${department}`, function (data, status) {
		if (status === 'success') {
			if (data) {
				let tempData = JSON.parse(data);

				if (tempData.length > 0) {
					$('#usertable > tbody').empty();
					for (let item of tempData) {
						let status, class_, icon, checkboxdisabled;
						if (item.status === 'Y') {
							status = "Active";
							class_ = "activestatus";
							icon = 'check';
						} else {
							status = "InActive";
							class_ = "inactivestatus";
							icon = 'times';
						}
						if (item.password !== '') {
							checkboxdisabled = `<input type="checkbox" class="singlecheckbox" onchange="singlecheckboxfun(event)" value="${item.email}" />`;
						} else {
							checkboxdisabled = `<input type="checkbox" class="singlecheckbox" value="${item.email}" />`;
						}
						let usertrdata = JSON.stringify(item);
						$('#usertable > tbody').append(
							`
							<tr>
								<td>${checkboxdisabled}</td>
								<td>${item.name}</td>
								<td>${item.email}</td>
								<td>${item.password}</td>
								<td>${item.tenth_percentage}</td>
								<td>${item.twelth_percentage}</td>
								<td>${item.ug_cgpa}</td>
								<td>${item.pg_cgpa}</td>
								<td>${item.yearofpass}</td>
								<td class="${class_}" onclick="updateuserdetails('${item.sno}','${status}')" title="Click for Status Change">
									<i class="fas fa-${icon}"></i> 
									${status}									
								</td>
								<td  onclick='updateuserholedetails(${usertrdata})'><i class="fas fa-pencil-alt"></i></td>
							</tr>
						`
						);
					}
					$('#usertable')
					.on( 'page.dt',   function () { 
						$('.checkall').prop('checked', false);
						email = [];
						checkallfun(); 
					} )
					.dataTable({
						
						retrieve: true,
						"aoColumnDefs": [
							{ 'bSortable': false, 'aTargets': [ 0 ] }
						 ],
						
					});
					
					checkallfun();
				} else {
					$('#usertable > tbody').empty();
					$('#usertable > tbody').append(
						`
						<tr class="text-center">
							<td colspan="13">No Data Available!!!</td>
						</tr>
					`
					);
					$('#usertable').dataTable({
						retrieve: true,
					});


				}
			} else {
				console.log(data);
			}
		} else {
			alert('Failed to Get Data!!!')
		}
	});
}

function updateuserholedetails(data) {

	$('.usersno').show();
	$.get(`updateuserdetails.php?course=${data.course}`, function (data, status) {
		if (status === 'success') {
			if (data) {
				let tempData = JSON.parse(data);
				$('select[name="department"]').empty();
				for (let item of tempData) {
					$('select[name="department"]').append(`
							<option value="${item.department}">${item.department}</option>
						`
					);
				}
			}
		} else {
			alert("Data: " + data + "\nStatus: " + status);
		}
	});
	$('select[name="collegeid"]').val(data.collegeid);
	$('input[name="name"]').val(data.name);
	$('input[name="sno"]').val(data.sno);
	$('input[name="mobile"]').val(data.mobileno);
	$('select[name="gender"]').val(data.gender);
	$('input[name="dob"]').val(data.dob);
	$('select[name="course"]').val(data.course);
	$('select[name="department"]').val(data.department);
	$('input[name="tenth_percentage"]').val(data.tenth_percentage);
	$('input[name="twelth_percentage"]').val(data.twelth_percentage);
	$('input[name="ug_cgpa"]').val(data.ug_cgpa);
	$('input[name="pg_cgpa"]').val(data.pg_cgpa);
	$('input[name="yearofpass"]').val(data.yearofpass);
	$('input[name="email"]').val(data.email).focus();
	$('button[name="useraddbtn"]').attr("name", "userupdatebtn");
	
}

function updateuserdetails(sno, status) {
	if (status === 'Active') {
		status = 'N';
	} else {
		status = 'Y';
	}
	$.get(`updateuserdetails.php?sno=${sno}&status=${status}`, function (data, status) {
		if (status === 'success') {
			userdetailsget(filtercollege, filtercourse, filterdepartment);
		} else {
			alert("Data: " + data + "\nStatus: " + status);
		}

	});
}


function departmentdetget() {

	$('select[name="excelcourse"]').change(function (e) {
		var course = $(this).val();
		$.get(`updateuserdetails.php?course=${course}`, function (data, status) {
			if (status === 'success') {
				if (data) {
					let tempData = JSON.parse(data);
					$('select[name="exceldepartment"]').empty();
					for (let item of tempData) {
						$('select[name="exceldepartment"]').append(`
								<option value="${item.department}">${item.department}</option>
							`
						);
					}
				}
			} else {
				alert("Data: " + data + "\nStatus: " + status);
			}
		});
	});

	$('select[name="course"]').change(function (e) {
		var course = $(this).val();
		$.get(`updateuserdetails.php?course=${course}`, function (data, status) {
			if (status === 'success') {
				if (data) {
					let tempData = JSON.parse(data);
					$('select[name="department"]').empty();
					for (let item of tempData) {
						$('select[name="department"]').append(`
								<option value="${item.department}">${item.department}</option>
							`
						);
					}
				}
			} else {
				alert("Data: " + data + "\nStatus: " + status);
			}
		});
	});


	$('select[name="filtercourse"]').change(function (e) {
		var course = $(this).val();
		$.get(`updateuserdetails.php?course=${course}`, function (data, status) {
			if (status === 'success') {
				if (data) {
					let tempData = JSON.parse(data);
					$('select[name="filterdepartment"]').empty();
					for (let item of tempData) {
						$('select[name="filterdepartment"]').append(`
								<option value="${item.department}">${item.department}</option>
							`
						);
					}
				}
			} else {
				alert("Data: " + data + "\nStatus: " + status);
			}
		});
	});
}


function passwordsend() {

	if (email.length > 0) {
		email.map((item, index) => {
			mailsend(item);
			
			if (index === (email.length - 1)) {
				
				$.confirm({
					title: 'Success',
					type: 'green',
					content: 'Login Details Send Successfully',
					autoClose: 'ok|1000',
					buttons: {						
						ok: function () {
							location.reload();
						}
					}
				});
			};
			
		});
	} else {
		$.alert({
			title: 'Info!',
			type: 'blue',
			content: 'Email not Selected!',
		});
		
	}
}

function mailsend(email) {
	$.get(`email.php?email=${email}`, function (data, status) {
		if (status === 'success') {

		} else {

		}
	});
}
