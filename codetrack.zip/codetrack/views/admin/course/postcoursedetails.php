

<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
</head>
<body>

<?php
	include_once('../../../config/connection.php');
	$username=$_SESSION['Email'];
	if(isset($_POST['courseaddbtn'])){
		$course = $_POST['course'];
		$department = $_POST['department'];
		$query = "SELECT * FROM `course` WHERE `course`='$course' AND `department`='$department'";
		$duplicatefind=mysqli_query($con,$query) or die(mysqli_error());
		if($duplicatefind){
			$rowcount=mysqli_num_rows($duplicatefind);
			if($rowcount === 0){
				$sql = "INSERT INTO `course`( `course`, `department`,  `createdby`) VALUES ('$course','$department','$username')";
				$result=mysqli_query($con,$sql) or die(mysqli_error());
				if($result){
					header('college.php');
					echo "<script>$.confirm({
						title: 'Success',
						content: 'Course Details Insert Successfully',
						autoClose: 'ok|1000',						
						buttons: {							
							ok: function () {
								location.href='course.php';
							}
						}
					});
					</script>";
					
				}else{
					echo '<script>alert('.mysqli_error().')</script>';
				}
			}else{
				echo "<script>$.confirm({
					title: 'Failure',
					content: 'Course Details Already Exists',
					autoClose: 'ok|1000',						
					buttons: {							
						ok: function () {
							location.href='course.php';
						}
					}
				});
				</script>";
				
			}
		}
		
	}
?>

</body>
</html>