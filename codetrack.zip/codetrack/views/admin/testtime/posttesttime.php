<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
</head>
<body>
<?php
	include_once('../../../config/connection.php');
	$username=$_SESSION['Email'];

	if(isset($_POST['testtimeaddbtn'])){
		$testtype = $_POST['testtype'];
        $questions = $_POST['questions'];
        $cutoff = $_POST['cutoff'];
        $time = $_POST['time'];
        
       
		$query = "SELECT * FROM `testtime` WHERE `testtype`='$testtype'";
		$duplicatefind=mysqli_query($con,$query) or die(mysqli_error());
		if($duplicatefind){
			$rowcount=mysqli_num_rows($duplicatefind);
			if($rowcount === 0){
				$sql = "INSERT INTO `testtime`(`testtype`,`questions`, `cutoff`,`time`, `createdby`) VALUES ('$testtype','$questions','$cutoff','$time','$username')";
				$result=mysqli_query($con,$sql) or die(mysqli_error());
				if($result){
					echo "<script>$.confirm({
						title: 'Success',
						content: 'Insert Test Time  Details Successfully',	
						autoClose: 'ok|1000',					
						buttons: {							
							ok: function () {
								location.href='testtime.php';
							}
						}
					});
					</script>";
					
				}else{
					echo '<script>alert('.mysqli_error().')</script>';
				}
			}else{
				$sql = "UPDATE `testtime` SET `time`='$time',`questions`='$questions',`cutoff`='$cutoff' WHERE `testtype`='$testtype'";
				$result=mysqli_query($con,$sql) or die(mysqli_error());
				if($result){
					echo "<script>$.confirm({
						title: 'Success',
						content: 'Update Test Time  Details Successfully',	
						autoClose: 'ok|1000',					
						buttons: {							
							ok: function () {
								location.href='testtime.php';
							}
						}
					});
					</script>";
					
				
				}else{
					echo '<script>alert('.mysqli_error().')</script>';
				}
			}
		}
		
	}
?>
</body>
</html>