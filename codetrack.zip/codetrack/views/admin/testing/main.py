print('Hello, wor1d!');
