<?php
	include_once('../../../../config/connection.php');

	$hrcomments = $_GET['hrcomments'];
	$email = $_GET['email'];
	$selectedstatus = $_GET['selectedstatus'];
	$termscondition = $_GET['termscondition'];
	$salary = $_GET['salary'];
	$sql = "UPDATE `result` SET `hrcomments`='$hrcomments',selectedstatus='$selectedstatus',termscondition='$termscondition',salary='$salary' WHERE `email`='$email'";

	$result=mysqli_query($con,$sql) or die(mysqli_error());

	
	if(isset($result)){
			
	}else{
		$oVal = (object)[];
		
	}	
?>

