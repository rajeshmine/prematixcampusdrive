let email = [];

$(document).ready(function () {
    $('.resulttablediv').hide();
});

function checkallfun(){
	$(".checkall").change(function () {
		var ischecked = $(this).is(':checked');
		if (ischecked) {
			$('.singlecheckbox').prop('checked', true);
			for (let i = 0; i < $('.singlecheckbox').length; i++) {
				let emailid = $('.singlecheckbox')[i];
				email.push(emailid.value);
			}
		} else {
			$('.singlecheckbox').prop('checked', false);
			email = [];
		}
	});
}

function singlecheckboxfun(){
	$(".singlecheckbox").each(function () {
		$(this).change(function () {			
			var ischecked = $(this).is(':checked');
			if (ischecked) {
                email.push($(this).val());
                console.log(email)
			} else {
				var removeItem = $(this).val()
				email = jQuery.grep(email, function(value) {
				return value != removeItem;
				});
				
			}
		});
	});
}


function filterresult(){
   
	let filtercollege = $('select[name="filtercollege"]').val();
	let filtercourse = $('select[name="filtercourse"]').val();
    let filterdepartment = $('select[name="filterdepartment"]').val();
    let filterdate = $('select[name="filterdate"]').val();
	if(filterdepartment && filtercourse && filtercollege && filterdate){
		getresult(filtercollege,filtercourse,filterdepartment,filterdate)
    }
    $('.checkall').prop('checked', false);
    $('.singlecheckbox').prop('checked', false);
    email = [];
	
	
}

function getresult(collegeid,course,department,date) {
    $('.resulttablediv').show();
    let trstatus;
    $.get(`getresult.php?collegeid=${collegeid}&course=${course}&department=${department}&date=${date}`, function (data, status) {
        if (status === 'success') {
            if (data) {
                let tempData = JSON.parse(data);
                if (tempData.length > 0) {
                    let checkboxdisabled;
                    $('#resulttable >tbody').empty();
                    for (var i = 0; i < tempData.length; i++) {
                        if ((+tempData[i].App_Result >= +tempData[i].App_Cutoff) && (+tempData[i].Tech_Result >= +tempData[i].Tech_Cutoff)) {
                            trstatus = 'successtr';
                        } else if ((+tempData[i].App_Result >= +tempData[i].App_Cutoff) || (+tempData[i].Tech_Result >= +tempData[i].Tech_Cutoff)) {
                            trstatus = 'warningtr';
                        } else {
                            trstatus = 'dangertr';
                        }
                        if(tempData[i].codingstatus === 'Y'){
                            checkboxdisabled = '<i class="fas fa-check teal"></i>';
                        }else{
                            checkboxdisabled = `<input type="checkbox" class="singlecheckbox" value="${tempData[i].email}" />`;
                        }
                        

                        $('#resulttable >tbody').append(`
                        <tr>
                        <td>${checkboxdisabled}</td>
                        <td>${i + 1}</td>
                        <td>${tempData[i].name}</td>
                        <td>${tempData[i].email}</td>												
                        <td>${tempData[i].App_Question}</td>												
                        <td  class="${trstatus}">${tempData[i].App_Result}</td>													
                        <td>${tempData[i].App_Cutoff}</td>													
                        <td>${tempData[i].Tech_Question}</td>													
                        <td  class="${trstatus}">${tempData[i].Tech_Result}</td>													
                        <td>${tempData[i].Tech_Cutoff}</td>													
                        </tr>
                                `
                        );

                    }
                    $('#resulttable').dataTable({
                        dom: 'Bfrtip',
                        retrieve: true,
                        buttons: [
                            'copy', 'csv', 'excel', 'pdf', 'print'
                        ]
                    });
                    checkallfun();
                    singlecheckboxfun();
                }
            } else {
                console.log(data);
            }
        } else {
            alert('Failed to Get Data!!!')
        }
    });
}


function passwordsend(){
	if (email.length > 0) {
		email.map((item, index) => {
			mailsend(item);
			if (index === (email.length - 1)) {
				
				$.confirm({
					title: 'Success',
					type: 'green',
					content: 'Login Details Send Successfully',
					autoClose: 'ok|1000',
					buttons: {						
						ok: function () {
							location.reload();
						}
					}
				});
			};
			
		});
	} else {
		$.alert({
			title: 'Info!',
			type: 'blue',
			content: 'Email not Selected!',
		});
		
	}
		
}




function mailsend(email){
	$.get(`email.php?email=${email}`, function (data, status) {
		if(status === 'success'){           
			
		}else{

		}		
	});
}

$(document).ready(function(){
    departmentdetget();
    interviewdateget();
});

function departmentdetget() {

	$('select[name="filtercourse"]').change(function (e) {
        var course = $(this).val();
		$.get(`departmentget.php?course=${course}`, function (data, status) {
			if (status === 'success') {
				if (data) {
					let tempData = JSON.parse(data);
					$('select[name="filterdepartment"]').empty();
					for (let item of tempData) {
						$('select[name="filterdepartment"]').append(`
								<option value="${item.department}">${item.department}</option>
							`
						);
					}
				}
			} else {
				alert("Data: " + data + "\nStatus: " + status);
			}
		});
    });
}

function interviewdateget() {
   
	$('select[name="filtercollege"]').change(function (e) {
        var collegeid = $(this).val();
		$.get(`interviewdateget.php?collegeid=${collegeid}`, function (data, status) {
			if (status === 'success') {
				if (data) {
					let tempData = JSON.parse(data);
					$('select[name="filterdate"]').empty();
					for (let item of tempData) {
						$('select[name="filterdate"]').append(`
								<option value="${item.interviewdate}">${item.interviewdate}</option>
							`
						);
					}
				}
			} else {
				alert("Data: " + data + "\nStatus: " + status);
			}
		});
    });
}