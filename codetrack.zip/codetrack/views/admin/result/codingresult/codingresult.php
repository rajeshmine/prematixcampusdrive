
<?php 
  include_once('../../../../config/connection.php');
  $role=$_SESSION['Role'];
  $name = $_SESSION['Name'];

  $collegeright = $_SESSION['collegeright']; 
  $courseright = $_SESSION['courseright']; 
  $userright = $_SESSION['userright']; 
  $questionright = $_SESSION['questionright']; 
  $testtimeright = $_SESSION['testtimeright']; 
  $usercreationright = $_SESSION['usercreationright']; 
  $resultright = $_SESSION['resultright'];
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Campus Drive</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
  <link rel="stylesheet" href="codingresult.css">
  <link rel="stylesheet" href="../../../../css/common.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css" />
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU"
    crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU"
    crossorigin="anonymous">
    <script src="../../../../js/common.js"></script>
    <script src="codingresult.js"></script>
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
	 <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
	 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" /> 
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
</head>

<body>
  <div class="wrapper">
    <nav id="sidebar">
      <div class="sidebar-header">
        <h3 class="fontsize22"> <span>Prematix<br/> Campus Drive <br/></span></h3>
        <p class="alignrgt">Online Test</p>
        <hr />
      </div>

      <ul class="list-unstyled components">
        <p><i class="fas fa-laptop-code"></i> Campus Drive</p>
        <?php
          if($collegeright === 'Y') {
            echo '<li>
                    <a href="../../college/college.php"><i class="far fa-building"></i>
                      College</a>
                  
                  </li>';
          }
        
          if($courseright === 'Y') {
            echo '<li>
            <a href="../../course/course.php"><i class="fab fa-leanpub"></i>
              Course</a>
           
          </li>';
          }
          if($userright === 'Y') {
            echo '<li >
            <a href="../../user/user.php"><i class="far fa-user"></i>
              Users</a>         
          </li>';
          }
          if($usercreationright === 'Y') {
            echo '<li>
            <a href="../../userRights/userRights.php"><i class="fas fa-check"></i>
              Users Rights</a>         
          </li>';
          }
          if($questionright === 'Y') {
            echo '<li >
            <a href="../../question/question.php"><i class="far fa-question-circle"></i>
              Questions</a>         
          </li>';
          }
          if($testtimeright === 'Y') {
            echo '<li >
            <a href="../../testtime/testtime.php"><i class="far fa-clock"></i>
              Test Time</a>         
          </li>';
          }
          if($resultright === 'Y') {
            echo '<li  class="active">
            <a href="#Result" data-toggle="collapse" aria-expanded="false"><i class="fas fa-clipboard-check"></i> Result</a>
            <ul class="collapse list-unstyled" id="Result">
              <li><a  href="../result.php">Apptitude & Technical</a></li>
              <li><a href="codingresult.php">Programming Round</a></li>
              <li><a href="../gdresult/gdresult.php">GD Round</a></li>
              <li><a href="../hrresult/hrresult.php">HR Round</a></li>
              <li><a href="../selectedresult/selectedresult.php">Selected Candidate</a></li>
            </ul>
        </li>';
          }
        ?>
        
      </ul>
    </nav>

    <div id="content">

      <nav class="navbar whitebg">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <button type="button" id="sidebarCollapse">
              <i class="fas fa-align-left"></i>
            </button>
          </div>
          <div class="collapse navbar-collapse" id="myNavbar">

            <ul class="nav navbar-nav navbar-right">
              <li>
                <a href="../../../../index.html"><i class="fas fa-home"></i> Home</a>
              </li>
              <li><a><i class="far fa-user"></i> <?php echo $name; ?></a></li>
              <li><a href="../../../../index.html"><i class="fas fa-power-off"></i> </a></li>
            </ul>
          </div>
        </div>
      </nav>


      <div class="container-fluid">  

          <div class="row mar0 pad10">
            <h5 class="headtxt">Programming Round Result</h5>
              <div class="col-sm-3">
                <select class="form-control inputstyle" name="filtercollege">
                  <option value="" selected disabled>Select College</option>
                  <?php
                      $gettesttype=mysqli_query($con,"SELECT * FROM college WHERE status = 'Y'");
                      while($row=mysqli_fetch_array($gettesttype)){                         
                      
                  ?>                        
                  <option class="text-uppercase" value="<?php  echo $row['collegeid'];?>"><?php echo $row['collegename'];?></option>
                  <?php }?>
                </select>
              </div>
              <div class="col-sm-3">
                  <select class="form-control inputstyle" name="filtercourse">
                      <option value="" selected disabled>Select Course</option>
                      <?php
                            $getcollege=mysqli_query($con,"SELECT DISTINCT course FROM course WHERE status = 'Y'");
                            while($row=mysqli_fetch_array($getcollege)){                         
                            
                        ?>                        
                            <option value="<?php  echo $row['course'];?>"><?php echo $row['course'];?></option>
                            <?php }?>
                  </select>
              </div>
              <div class="col-sm-3">
                  <select class="form-control inputstyle" name="filterdepartment">
                      <option value="" selected disabled>Select Department</option>
                      
                  </select>
              </div>
              <div class="col-sm-3">
                <select class="form-control inputstyle" name="filterdate">
                  <option value="" selected disabled>Select Date</option>
                 
                </select>
              </div>
              </div>
              <div class="row mar0 pad10 text-right">
              <div class="col-sm-12">
                  <div>
                      <button class="filterbtnresult" onclick="filterresult()">Filter</button>
                  </div>
              </div>
          </div>

          <div class="row mar0 pad10">
            <div class="table-responsive pad10 whitebg resulttablediv">
             
              <table id="resulttable" class="table table-bordered table-condensed">
                <thead>
                  
                  <tr>						
                    <th><input class="checkall" type="checkbox"></th>
                    <th>Sno</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>CollegeID</th>
                    <th>Course</th>
                    <th>Department</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
              <div class="text-right">
                  <button class="sendpasswordbtn" onclick="passwordsend()">Submit Level 3 Candidates</button>
              </div>
            </div>
          </div>
          
         
          <div class="row mar0 Problemsdiv pad10">
          <h5 class="headtxt">Problems</h5>
                <div class="codinganswer">
                  </div>
            </div>
          <br/>

      </div>
    </div>
  </div>
</body>

</html>