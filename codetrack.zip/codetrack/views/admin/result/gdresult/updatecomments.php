<?php
	include_once('../../../../config/connection.php');

	$gdcomments = $_GET['gdcomments'];
	$hrstatus = $_GET['hrstatus'];
	$email = $_GET['email'];
	$sql = "UPDATE `result` SET `gdcomments`='$gdcomments',`hrstatus`='$hrstatus' WHERE `email`='$email'";

	$result=mysqli_query($con,$sql) or die(mysqli_error());

	
	if(isset($result)){
			
	}else{
		$oVal = (object)[];
		
	}	
?>



