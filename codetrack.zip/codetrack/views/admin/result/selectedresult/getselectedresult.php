<?php
	include_once('../../../../config/connection.php');

	$collegeid = $_GET['collegeid'];
	$course = $_GET['course'];
	$department = $_GET['department'];
	$date = $_GET['date'];
	$sql = "SELECT * FROM result WHERE selectedstatus='Y' AND collegeid='$collegeid'  AND course='$course' AND department='$department'  AND DATE(createdon)= '$date'  GROUP BY `email`";

	$result=mysqli_query($con,$sql) or die(mysqli_error());

	
	while($rows=mysqli_fetch_array($result)){
		$data[] = $rows;
	}
	if(isset($data)){
		echo json_encode($data);	
	}else{
		$oVal = (object)[];
		echo json_encode($oVal);
	}	
?>

