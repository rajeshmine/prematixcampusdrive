
<?php   
    include_once('../../../config/connection.php');
    $email = $_GET['email'];
	$sql = "UPDATE `login` SET `teststatus`='Coding',`status`='Y' WHERE `email`='$email'";
    $result=mysqli_query($con,$sql) or die(mysqli_error());	
    
    $query = "SELECT * FROM `login` WHERE `email`='$email'";
    $userdetails=mysqli_query($con,$query) or die(mysqli_error());
    	
    while($rows=mysqli_fetch_array($userdetails)){


        $query = "UPDATE `result` SET `codingstatus`='Y' WHERE `email`='$email'";
	    $result1=mysqli_query($con,$query) or die(mysqli_error());	

        error_reporting(E_STRICT);
        date_default_timezone_set('America/Toronto');
        require("../../../PHPMailer/class.phpmailer.php");
        $mail = new PHPMailer();
        $body = "<html>
        <head>
        </head>
        <body>
            <h3>Greetings From Prematix</h3>
            <p>Dear <b>" . $rows['name'] . " </b></p>
            <p style='text-transform:uppercase;font-weight:bold;'>Congratulations!</p> 
            <p>You are Completed the Level 1 Prematix Online Test Successfully.</p>
            <p style='text-transform:uppercase;font-weight:bold;'>Details!</p> 
            <p>Name : <span style='color:green'>" . $rows['name'] . "</span></p> 
            <p>College Name : <span style='color:green'>" . $rows['collegename'] . "</span></p> 
            <p>Course : <span style='color:green'>" . $rows['course'] . "</span></p> 
            <p>Department : <span style='color:green'>" . $rows['department'] . "</span></p> 
            <p>Apptitude/Technical : <span style='color:green'>Pass</span></p> 
            <p><a href='http://prematix.com/campus/'>Click here to Start the Test </a></p>
            <p>All the Best!!!</p>
            <p><b>Regards</b></p>
            <p>Prematix Team</p>
            
        </body>
        
        </html>";
        $mail->IsSMTP();
        $mail->SMTPDebug  = 2;
        $mail->SMTPAuth   = true; 
        $mail->SMTPSecure = "ssl"; 
        $mail->Host       = "smtp.gmail.com"; 
        $mail->Port       = 465;              
       
        $mail->Username   = "apps@prematix.com";  
        $mail->Password   = "Preapps123";  
        $mail->SetFrom("apps@prematix.com", "Prematix");
        $mail->AddReplyTo("apps@prematix.com", "Prematix"); 
        $mail->Subject    = "Prematix Campus Drive";
        $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; 
        $mail->MsgHTML($body);
        $address = $email; 
        $mail->AddAddress($address);
        if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
        echo json_encode($mail);
        }
    }


	
?>
