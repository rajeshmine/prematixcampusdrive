var formdata = new FormData();
let headers = new Headers();
let isEditForm = false;
let selectedRights = {
  collegeright: false,
  courseright: false,
  userright: false,
  questionright: false,
  testtimeright: false,
  usercreationright: false,
  resultright: false,
};

window.onload = () => {
  appendRights();
  userRightsGet();
}
let totalRights = [
  { name: 'College Module', selected: false, feildName: 'collegeright' },
  { name: 'Course Module', selected: false, feildName: 'courseright' },
  { name: 'Users Module', selected: false, feildName: 'userright' },
  { name: 'Questions Module', selected: false, feildName: 'questionright' },
  { name: 'Test Timing Module', selected: false, feildName: 'testtimeright' },
  { name: 'User Rights Module', selected: false, feildName: 'usercreationright' },
  { name: 'Results Module', selected: false, feildName: 'resultright' }
];

var appendRights = () => {
  $('#rightsPrint').empty();
  totalRights.map((item, index) => {
    let temp = `<div class="col-md-4" key="${index}">
        <div class="checkbox">
          <label><input type="checkbox" name="${item.feildName}" ${item.selected ? 'checked' : ''} onchange="handleChange(event)">${item.name}</label>
        </div>
      </div>`;
    $('#rightsPrint').append(temp);
  });
}

function postRec(url, formdata, headers, callback) {
  try {
    fetch(url, {
      method: 'POST',
      headers: headers,
      body: formdata,
    }).then((response) => {
      if (response.status === 200) {
        return response.json()
      } else {
        throw response;
      }
    }).then((responseData) => {
      callback(responseData);
    }).catch((err) => {
      callback({
        status: false,
        message: "Network failed",
        error: err
      });
    });
  } catch (error) {
    callback({
      status: false,
      message: 'Something went wrong!'
    })
  }
}

function post(url, obj, callback) {
  url = url;
  postRec(url, obj, headers, (res) => {
    callback(res);
  });
}


function userRightsGet() {
  let url = 'rightsget.php';
  formdata.delete("type");
  formdata.append("type", 'allUserRights');
  post(url, formdata, (res) => {
    if (res.statusCode !== 200) return alert(res.message);
    appendTable(res.data)
  });
}

function handleChange(e) {
  if (e.target !== undefined) { const { name, checked } = e.target; return selectedRights[name] = checked; }
  Object.keys(selectedRights).forEach((key) => {
    selectedRights[key] = false;
  });
}


function handleSubmit(e) {
  e.preventDefault();
  if (!isEditForm) return insertDoc();
  if (isEditForm) return updateDoc();
}

function insertDoc() {
  let url = 'rightsget.php';
  let username = $('#username').val();
  let password = $('#password').val();
  let role = $('#role').val();
  formdata.delete("username");
  formdata.append("username", username);
  formdata.delete("password");
  formdata.append("password", password);
  formdata.delete("role");
  formdata.append("role", role);
  formdata.delete("type");
  formdata.append("type", 'InsertDoc');
  Object.keys(selectedRights).forEach((key) => {
    formdata.delete(key);
    let status = selectedRights[key] ? "Y" : "N";
    formdata.append(key, status);
  });
  post(url, formdata, (res) => {
    if (res.statusCode !== 200) return alert(res.message);
    $('#insertForm')[0].reset();
    userRightsGet();
    handleChange("");
  });
}

function updateDoc() {
  let url = 'rightsget.php';
  let username = $('#username').val();
  let password = $('#password').val();
  let role = $('#role').val();
  formdata.delete("username");
  formdata.append("username", username);
  formdata.delete("password");
  formdata.append("password", password);
  formdata.delete("role");
  formdata.append("role", role);
  formdata.delete("type");
  formdata.append("type", 'UpdateDoc');
  Object.keys(selectedRights).forEach((key) => {
    formdata.delete(key);
    let status = selectedRights[key] ? "Y" : "N";
    formdata.append(key, status);
  });
  post(url, formdata, (res) => {
    if (res.statusCode !== 200) return alert(res.message);
    isEditForm = false;
    $('#insertForm')[0].reset();
    userRightsGet();
    handleChange("");
    totalRights.map((a) => {
      a.selected = false;
    });
    appendRights();
  });
}


function editRow(data = {}) {
  totalRights.map((a) => {
    a.selected = false;
  });
  handleChange('');
  formdata.delete("userid");
  formdata.append("userid", data.sno);
  $('#username').val(data.name);
  $('#password').val(data.password);
  $('#role').val();
  Object.keys(data).forEach((key) => {
    totalRights.map((a) => {
      if (a.feildName === key && data[key] === 'Y') a.selected = true;
    });
  });
  Object.keys(data).forEach((key) => {
    if (data[key] === 'Y') selectedRights[key] = true;
  });
  isEditForm = true;
  appendRights();
}





// Rights insert

function appendTable(data = []) {
  $('#userrightstable > tbody').empty();
  for (let item of data) {
    let tempJson = JSON.stringify(item);
    $('#userrightstable > tbody').append(
      ` <tr>
        <td onclick='editRow(${tempJson})'>${item.sno}</td>
        <td>${item.name}</td>
        <td>${item.password}</td> 
        <td>${item.role}</td> 
        <td class="${item.collegeright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.collegeright === 'Y' ? 'check' : 'times'}"></i></td>
        <td class="${item.courseright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.courseright === 'Y' ? 'check' : 'times'}"></i></td> 
        <td class="${item.userright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.userright === 'Y' ? 'check' : 'times'}"></i></td>  
        <td class="${item.questionright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.questionright === 'Y' ? 'check' : 'times'}"></i></td>  
        <td class="${item.testtimeright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.testtimeright === 'Y' ? 'check' : 'times'}"></i></td>   
        <td class="${item.usercreationright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.usercreationright === 'Y' ? 'check' : 'times'}"></i></td>    
        <td class="${item.resultright === 'Y' ? 'activestatus' : 'inactivestatus'}"><i class="fas fa-${item.resultright === 'Y' ? 'check' : 'times'}"></i></td>   
      </tr>
    `
    );
  }

  $('#userrightstable').dataTable();
}