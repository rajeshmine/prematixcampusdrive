<?php
include_once('./../../../config/connection.php');
$loggedUser = $_SESSION['Email'];
// All User List
if (isset($_POST['type'])) {
    $type = $_POST['type'];
    if ($type == "InsertDoc") {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role = $_POST['role'];
        $college = $_POST['collegeright'];
        $course = $_POST['courseright'];
        $users = $_POST['userright'];
        $questions = $_POST['questionright'];
        $testtiming = $_POST['testtimeright'];
        $userrights = $_POST['usercreationright'];
        $results = $_POST['resultright'];
        $query = mysqli_query($con, "INSERT INTO `login`( `name`, `password`,`role`,`collegeright`, `courseright`, `userright`, `questionright`, `testtimeright`, `usercreationright`, `resultright`,`createdby`) VALUES ('$username','$password','$role','$college','$course','$users','$questions','$testtiming','$userrights','$results','$loggedUser')") or die(mysqli_error($con));
        if ($query) {

            $oVal = (object)[];
            $oVal->statusCode = 200;
            $oVal->message = "User Created Successfully.";
            echo json_encode($oVal);
        } else {
            $oVal = (object)[];
            $oVal->statusCode = 400;
            $oVal->message = mysqli_error($con);
            echo json_encode($oVal);
        }
    }
    if ($type == "UpdateDoc") {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role = $_POST['role'];
        $college = $_POST['collegeright'];
        $course = $_POST['courseright'];
        $users = $_POST['userright'];
        $questions = $_POST['questionright'];
        $testtiming = $_POST['testtimeright'];
        $userrights = $_POST['usercreationright'];
        $results = $_POST['resultright'];
        $userid = $_POST['userid'];
        $query = mysqli_query($con, "UPDATE `login` SET  `name`='$username',`password`='$password',`role`='$role',`collegeright`='$college',`courseright`='$course',`userright`='$users',`questionright`='$questions',`testtimeright`='$testtiming',`usercreationright`='$userrights',`resultright`='$results' WHERE `sno` = '$userid'") or die(mysqli_error($con));
        if ($query) {
            $oVal = (object)[];
            $oVal->statusCode = 200;
            $oVal->message = "User Updated Successfully.";
            echo json_encode($oVal);
        } else {
            $oVal = (object)[];
            $oVal->statusCode = 400;
            $oVal->message = mysqli_error($con);
            echo json_encode($oVal);
        }
    }

    if ($type == "allUserRights") {
        $query = mysqli_query($con, "SELECT * FROM `login` WHERE NOT role ='user'") or die(mysqli_error($con));
        while ($rows = mysqli_fetch_assoc($query)) {
            $data[] = $rows;
        }
        if (isset($data)) {
            $oVal = (object)[];
            $oVal->statusCode = 200;
            $oVal->data = $data;
            echo json_encode($oVal);
        } else { 
            $oVal = (object)[];
            $oVal->statusCode = 400;
            $oVal->message = mysqli_error($con);
            echo json_encode($oVal);
        }
    }

}

// perticular User
if (isset($_POST['userId'])) {
    $userId = $_POST['userId'];
    $query = mysqli_query($con, "SELECT * FROM `login` WHERE sno = '$userId'") or die(mysqli_error($con));
    while ($rows = mysqli_fetch_assoc($query)) {
        $data[] = $rows;
    }
    if (isset($data)) {
        $oVal = (object)[];
        $oVal->statusCode = 200;
        $oVal->data = $data;
        echo json_encode($oVal);
    } else {
        $oVal = (object)[];
        $oVal->statusCode = 400;
        $oVal->message = mysqli_error($con);
        echo json_encode($oVal);
    }
}



?>